from ID_settings import *
from ComArduino2 import *

import time
from string import *
from threading import *

# error codes
TRAY_NOT_INSERTED = 0x001
PISTON_EXTEND_FAIL = 0x002

def extend_retract_piston(relayID, tray_sensor_id, piston_sensor_id):
    res = get_sensor_data()

    # return error code if there is no tray in the slot
    if res[tray_sensor_id] != 1:
        return TRAY_NOT_INSERTED
    
    # flash the LED red to warn workers
    flash_red(pause_interval=0.2, num_flashes=6)
    
    led_red_on()
    
    # extend the pisten
    set_relay_status(relayID=relayID, status=RELAY_ON)

    # time passed in seconds sinse the pisten started extending
    time_elapsed = 0

    # time given for pisten to fully extend
    timeout = 10

    # wait for pisten to fully extend
    while res[piston_sensor_id] != 1:
        start = time.time()

        res = get_sensor_data()

        end = time.time()
        loop_time = end - start
        time_elapsed += loop_time

        # if pisten doesn't extend within a reasonable time, returns error code
        if time_elapsed > timeout:
            # retract the pisten to give access to tray
            set_relay_status(relayID=relayID, status=RELAY_OFF)
            return PISTON_EXTEND_FAIL
    
    # how long the pisten stays fully extended before retracting
    press_time = 2

    time.sleep(press_time)

    # retract the pisten
    set_relay_status(relayID=relayID, status=RELAY_OFF)

    led_green_on()

    # exit success
    return 0

def flash_red(pause_interval, num_flashes):
    for _ in range(num_flashes):
        time.sleep(pause_interval)
        led_red_on()
        time.sleep(pause_interval)
        led_off()

def led_green_on():
    led_on("green")

def led_red_on():
    led_on("red")

def led_yellow_on():
    led_on("yellow")

# takes in a string for the color: "green", "red", "yellow"
def led_on(color):
    color = color.lower()
    if color == "green":
        set_relay_status(green_light_id, RELAY_ON)
        set_relay_status(red_light_id, RELAY_OFF)
    elif color == "red":
        set_relay_status(green_light_id, RELAY_OFF)
        set_relay_status(red_light_id, RELAY_ON)
    elif color == "yellow":
        set_relay_status(green_light_id, RELAY_ON)
        set_relay_status(red_light_id, RELAY_ON)
    else:
        pass

def led_off():
    set_relay_status(green_light_id, RELAY_OFF)
    set_relay_status(red_light_id, RELAY_OFF)

def lock():
    error_code = extend_retract_piston(lock_relay_id, lock_tray_sensor_id, lock_piston_sensor_id)
    print(error_code)
    return error_code

def unlock():
    error_code = extend_retract_piston(unlock_relay_id, unlock_tray_sensor_id, unlock_piston_sensor_id)
    print(error_code)
    return error_code

def chicken_mode(event):
    flash_red(pause_interval=0.2, num_flashes=6)

    pause_interval = 0.3
    while not event.is_set():
        led_green_on()
        time.sleep(pause_interval / 2.0)
        set_relay_status(relayID=unlock_relay_id, status=RELAY_ON)
        led_red_on()
        time.sleep(pause_interval / 2.0)
        set_relay_status(relayID=lock_relay_id, status=RELAY_ON)

        led_yellow_on()
        time.sleep(pause_interval / 2.0)
        set_relay_status(relayID=unlock_relay_id, status=RELAY_OFF)
        time.sleep(pause_interval / 2.0)
        set_relay_status(relayID=lock_relay_id, status=RELAY_OFF)

    led_red_on()
    time.sleep(2)
    led_green_on()

    

def CLI():
    led_green_on()
    
    chicken_mode_on = False
    chicken_event = Event()

    chicken_thread = Thread(target=chicken_mode, args=(chicken_event,))

    is_running = True
    while is_running:
        # gets user input
        userin = input(">>>").lower()
        # figures out what to do with input
        if userin == "break":
            reset_relays()
            print("Have you paid your taxes yet?")
            is_running = False
        if userin == "unlock":
            unlock_res = unlock()
            print(unlock_res)
        if userin == "lock":
            lock_res = lock()
            print(lock_res)
        if "reset" in userin.split():
            reset_relays()

        if userin == "chicken":
            if not chicken_mode_on:
                # sets is_set() to False
                chicken_event.clear()
                chicken_thread.start()
                chicken_mode_on = True
            else:
                chicken_event.set()
                chicken_thread.join()
                chicken_thread = Thread(target=chicken_mode, args=(chicken_event,))
                chicken_mode_on = False

CLI()