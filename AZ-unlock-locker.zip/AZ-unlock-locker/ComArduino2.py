from ID_settings import *

import serial

import time

# local global variables

startMarker = 60 # <
endMarker = 62 # >

# NOTE the user must ensure that the serial port and baudrate are correct
serPort = "COM6"
baudRate = 115200


relay_status = [False, False, False, False]

# true if pc is sending a message to the arduino
message_sending = False

# true if program is waiting for Arduino to send message to serial
message_receiving = False


# NOTE if the program is waiting for Arduino to send a message to serial,
# this function wont do anything
def set_relay_status(relayID, status):
  relay_status[relayID-1] = status
  # send message to the Arduino to set relay status
  send_receive_data("<"+str(relayID)+","+str(status)+">")

def get_relay_status(relayID):
  return relay_status[relayID-1]

def toggle_relay(relayID):
  global relay_status
  if relay_status[relayID-1] == 1:
    set_relay_status(relayID, 0)
  else:
    set_relay_status(relayID, 1)

def toggle_relay_1():
    toggle_relay(1)

def toggle_relay_2():
    toggle_relay(2)

def toggle_relay_3():
    toggle_relay(3)

def toggle_relay_4():
    toggle_relay(4)

# Turns off all the relays
def reset_relays():
  for i in range(len(relay_status)):
    set_relay_status(relayID=i+1, status=RELAY_OFF)


# returns sensor data in the form of: unlockTray, unlockMag, lockTray, lockMag
def get_sensor_data():
  sensorData = send_receive_data("<-1,-1>").split(",")
  res = [eval(i) for i in sensorData]
  return res

def wait_for_availability():
  wait_interval = 0.05
  while message_receiving:
    time.sleep(wait_interval)
    pass
  while message_sending:
    time.sleep(wait_interval)
    pass

def sendToArduino(sendStr):
  global message_sending
  wait_for_availability()

  message_sending = True
  ser.write(sendStr)
  message_sending = False

def recvFromArduino():
  global message_receiving
  wait_for_availability()
  # check to see if ser object exists
  try:
    ex = ser
  except NameError:
    return
  
  global startMarker, endMarker

  ck = ""
  x = "z" # any value that is not an end- or startMarker
  byteCount = -1 # to allow for the fact that the last increment will be one too many

  message_receiving = True

  # wait for the start character
  while  ord(x) != startMarker: 
    x = ser.read().decode()
  
  # save data until the end marker is found
  while ord(x) != endMarker:
    if ord(x) != startMarker:
      ck = ck + x
      byteCount += 1
    x = ser.read().decode()

  message_receiving = False
  
  return(ck)


#============================

# this function should be called right after a serial object is created
# waits for Arduino to send ready message
def waitForReadyMessage():
   # wait until the Arduino sends 'Arduino Ready' - allows time for Arduino reset
   # it also ensures that any bytes left over from a previous message are discarded

    ready_message = "Arduino is ready"

    msg = ""

    # make sure ser exists
    try:
      # wait for Arduino to send ready message to the serial
      while msg.find(ready_message) == -1:
        while ser.inWaiting() == 0:
          pass
        msg = recvFromArduino()

    except NameError:
      pass

      
#======================================

def send_receive_data(testData):
  teststr = testData.encode('utf-8')

  sendToArduino(teststr)

  # wait for Arduino to finish sending message to serial
  while ser.inWaiting() == 0:
    pass
        
  dataRecvd = recvFromArduino()

  return dataRecvd

def recieve_from_arduino_and_print():
  while ser.inWaiting() == 0:
    pass
        
  dataRecvd = recvFromArduino()
  print("Reply Received  " + dataRecvd)

  print("===========")
  
  return dataRecvd


def close_serial():
  ser.close()



print()
print()


try:
  ser = serial.Serial(serPort, baudRate)
  print("Serial port " + serPort + " opened  Baudrate " + str(baudRate))

except serial.SerialException:
  print("Could not open serial connection to arduino")
  is_running = False


waitForReadyMessage()
