# Global Variables

# Constants that represent the IDs of arduino controlled relays
lock_relay_id = 2
unlock_relay_id = 1
green_light_id = 4
red_light_id = 3

# Constants that represent the IDs of sensors
unlock_tray_sensor_id = 0
unlock_piston_sensor_id = 1
lock_tray_sensor_id = 2
lock_piston_sensor_id = 3

# Settings that control how the program runs.
headless = True

relay_buttons = []

RELAY_ON = 1
RELAY_OFF = 0

SENSOR_TRIGGERED = 1
SENSOR_IDLE = 0
