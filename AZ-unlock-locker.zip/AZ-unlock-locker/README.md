# AZ-unlock-locker

# Error Codes 
 THESE ARE NOT FINALIZED
 
0x001: Tray not detected  
0x002: System timed out, either piston got stuck or there was an obstruction.  
 
