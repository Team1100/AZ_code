from pygame_toolkit import *
from ComArduino2 import get_sensor_data
import pygame
import math
import time
from ID_settings import *
from CLI import *

Win = Window((1280, 720), "Adam and Fred's crazy cool potato cannon v2", color=Colors.STEELBLUE)


lock_button = Button(Win, (80, 30), (500, 300), Colors.BLUE, label="LOCK", name="lock_button", border_size=8, function=lock)
unlock_button = Button(Win, (80, 370), (500, 300), Colors.BLUE, label="UNLOCK", name="unlock_button", border_size=8,function=unlock)
chicken_mode_button = Button(Win, (660, 30), (540, 300), Colors.BLUE, label="CHICKENSSS", name="chicken_mode_button", border_size=8)
sensor_1 = Button(Win, (660, 370), (540, 130), Colors.CORNFLOWERBLUE, label="Tray Sensor 1", name="sensor_1", clickable=False, border_size=7)
sensor_2 = Button(Win, (660, 540), (540, 130), Colors.CORNFLOWERBLUE, label="Tray Sensor 2", name="sensor_2", clickable=False, border_size=7)

Win.add_element(lock_button)
Win.add_element(unlock_button)
Win.add_element(chicken_mode_button)
Win.add_element(sensor_1)
Win.add_element(sensor_2)

on = True
chicken_index = Win.get_element_index("chicken_mode_button")
sensor_1_index = Win.get_element_index("sensor_1")
sensor_2_index = Win.get_element_index("sensor_2")

Clock = pygame.time.Clock()
while on:
    color = (abs(math.sin(time.time() * 4) * 255), abs(math.sin(time.time() * 4) * 255), abs(math.sin(time.time() * 4) * 255))
    Win.update()

    Win.elements[chicken_index].set_label_color(color)

    res = get_sensor_data()

    if res[unlock_tray_sensor_id] != 0:
        Win.elements[sensor_1_index].set_color(Colors.GREEN)
    else:
        Win.elements[sensor_1_index].set_color(Colors.RED)
    if res[lock_tray_sensor_id] != 0:
        Win.elements[sensor_2_index].set_color(Colors.GREEN)
    else:
        Win.elements[sensor_2_index].set_color(Colors.RED)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            on = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                on = False

    Clock.tick(30)
