
from ComArduino2 import send_receive_data
from ID_settings import *

import threading
import time
import sys




"""
def unlock():
    global time_elapsed
    for _ in range(11):
        time.sleep(.2)
        toggle_relay(red_light_id)
    sensorData = send_receive_data("<-1,-1>").split(",")
    res = [eval(i) for i in sensorData]
    if res[unlock_tray_sensor_id] != 1:
        toggle_relay(green_light_id)
        return "0x001"
    toggle_relay(lock_relay_id)
    # Constantly checks to see if the sensor has been triggered
    # This indicates that the piston has extended
    while res[1] != 1:
        start = time.time()
        sensorData = send_receive_data("<-1,-1>").split(",")
        res = [eval(i) for i in sensorData]
        end = time.time()
        loop_time = end - start
        time_elapsed += loop_time

        # If piston is "extended" for longer than about 10 seconds, then the system times out and retracts the piston
        if time_elapsed > timeout:
            time_elapsed = 0
            toggle_relay(lock_relay_id)
            return "0x002"
    time.sleep(press_time)
    print("Module Unlocked")
    toggle_relay(lock_relay_id)
    toggle_relay(red_light_id)
    toggle_relay(green_light_id)
    return 0


def lock():

    global time_elapsed
    for _ in range(11):
        time.sleep(.2)
        toggle_relay(red_light_id)
    sensorData = send_receive_data("<-1,-1>").split(",")
    res = [eval(i) for i in sensorData]
    if res[lock_tray_sensor_id] != 1:
        return "0x001"
    toggle_relay(unlock_relay_id)
    while res[3] != 1:
        sensorData = send_receive_data("<-1,-1>").split(",")
        res = [eval(i) for i in sensorData]
        time.sleep(loop_time)
        time_elapsed += loop_time
        if time_elapsed > timeout:
            time_elapsed = 0
            toggle_relay(unlock_relay_id)
            return "0x002"
    time.sleep(press_time)
    print("Module Locked")
    toggle_relay(unlock_relay_id)
    return 0

def chicken_mode():
    i = 0
    while i < 50:
        i+=1
        time.sleep(0.15)
        toggle_relay_1()
        time.sleep(0.15)
        toggle_relay_2()

# cli general func
def CLI():
    global is_running, press_time, timeout, loop_time, time_elapsed
    press_time = 2
    timeout = 5
    loop_time = 0.01
    time_elapsed = 0
    timed_out = False
    while is_running:
        to_disable = []
        # gets user input
        userin = input(">>>").lower()
        sensorData = send_receive_data("<-1,-1>").split(",")
        # figures out what to do with input
        if userin == "break":
            print("Have you paid your taxes yet?")
            is_running = False
            sys.exit()
        if userin == "unlock":
            unlock_res = unlock()
            print(unlock_res)

        if userin == "lock":
            lock_res = lock()
            print(lock_res)
        if "reset" in userin.split():
            reset_relays()



# makes a thread running the CLI, so you can interact with it using the python terminal, might n+ot play nicely with sensor debug prints rn
def run_CLI():
    global is_running
    running = threading.Event()
    running.set()

    cli_thread = threading.Thread(target=CLI)
    cli_thread.start()

    # we need to add a check to all the other functions so that if the program isnt running it turns itself off properly.
    if not is_running:
        running.clear()
        cli_thread.join()


# true if pc is sending a message to the arduino
message_sending = False
message_receiving = False

# False is off and True is on
relay_status = [False, False, False, False]
relay_buttons = []

recieve_sensor_data = False

program_is_closing = False

sensorData = []

sensor_delay = .2

def blocking_function():
    global message_receiving, is_running, sensor_delay
    while is_running:
        if not message_sending and not program_is_closing:
            # Format <Optical,Prox>
            message_receiving = True
            sensorData = send_receive_data("<-1,-1>").split(",")
            res = [eval(i) for i in sensorData]

            message_receiving = False
            time.sleep(0.15)
        else:

            time.sleep(sensor_delay)
    print("Sensor thread is done")


# running must be defined before sensor_thread
running = threading.Event()
sensor_thread = threading.Thread(target =blocking_function)


# This separate thread constantly reads sensor data
def start_sensor_thread():
    global sensor_thread
    
    running.set()
    
    sensor_thread.start()
    

def toggle_relay(relayID):
    global message_receiving
    if not message_receiving:
        global message_sending
        message_sending = True

        if relay_status[relayID-1]:
                if not headless:
                    relay_buttons[relayID-1].configure(text="off",bg="red")
                send_receive_data("<"+str(relayID)+",0>")
        else:
                if not headless:
                    relay_buttons[relayID-1].configure(text="on",bg="green")
                send_receive_data("<"+str(relayID)+",1>")

        relay_status[relayID-1] = not relay_status[relayID-1]
        message_sending = False


def toggle_relay_1():
    if not message_sending:
        toggle_relay(1)

def toggle_relay_2():
    if not message_sending:
        toggle_relay(2)
def toggle_relay_3():
    if not message_sending:
        toggle_relay(3)
def toggle_relay_4():
    if not message_sending:
        toggle_relay(4)

# Turns off all the relays
def reset_relays():
    global message_receiving
    if not message_receiving:
        global message_sending
        message_sending = True
        for i in range(len(relay_buttons)):
            if relay_status[i]:
                relay_buttons[i].configure(text="off",bg="red")
                print("Turning Relay " + str(i+1) + " off")
                relay_status[i] = not relay_status[i]
                
                send_receive_data("<"+str(i+1)+",0>")
        message_sending = False

def on_exit():
    global is_running
    global program_is_closing
    program_is_closing = True
    is_running = False
    time.sleep(sensor_delay+.1)
    
    print("Closing Program")
    global message_receiving
    global message_sending
    #while message_receiving:
        #print("Message Receiving: " + str(message_receiving))
    message_receiving = False
    message_sending = False
    reset_relays()

    # give the sensor thread time to stop
    time.sleep(sensor_delay + 0.2)

    # stops the sensor thread
    running.clear()

    # stops main thread until the sensor thread is destroyed
    #sensor_thread.join()

    #print("Is alive:", sensor_thread.is_alive())

"""


