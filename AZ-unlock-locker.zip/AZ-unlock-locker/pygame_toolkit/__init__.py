from pygame_toolkit.button import Button
from pygame_toolkit.window import Window
from pygame_toolkit.colors import Colors


print("Thank you for using the pygame toolkit libray, the worst one install solution for all your simple GUI needs")