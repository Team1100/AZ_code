import pygame
import time
from pygame_toolkit.colors import Colors

class Button:
    def __init__(self, window, position, dimensions, color, function=None, label=None, name="Button", click_cooldown=1, clickable=True, border_size=12, label_color=Colors.BLACK):
        self.window = window.window
        self.position = position
        self.dimensions = dimensions
        self.color = color
        self.function = function
        self.label = label
        self.cooldown = click_cooldown
        self.name = name
        self.cooldown_start = 0
        self.is_clickable = clickable
        self.border_size = border_size
        self.label_color = label_color

        self.is_renderable = True



    def render(self):

        w_border_percentage = 1 - (self.border_size / self.dimensions[0])
        h_border_percentage = 1 - (self.border_size / self.dimensions[1])
        pygame.draw.rect(self.window, Colors.BLACK,(self.position[0], self.position[1], self.dimensions[0], self.dimensions[1]))
        pygame.draw.rect(self.window, self.color, (self.position[0], self.position[1], self.dimensions[0] * w_border_percentage, self.dimensions[1] * h_border_percentage))

        if time.time() - self.cooldown_start < self.cooldown:
            pygame.draw.rect(self.window, self.color, (self.position[0], self.position[1], self.dimensions[0], self.dimensions[1]))
        if not self.is_clickable:
            pygame.draw.rect(self.window, Colors.BLACK, (self.position[0] - self.border_size, self.position[1] - self.border_size, self.dimensions[0] + self.border_size * 2, self.dimensions[1] + self.border_size * 2))
            pygame.draw.rect(self.window, self.color, (self.position[0], self.position[1], self.dimensions[0], self.dimensions[1]))

        font = pygame.font.Font('resources\\monocraft.otf', 50)
        text = font.render(self.label, True, self.label_color)
        size = text.get_size()
        if not time.time() - self.cooldown_start < self.cooldown:
            self.window.blit(text, (self.position[0] + ((self.dimensions[0]* .96) / 2) - (size[0] / 2), self.position[1] + ((self.dimensions[1]* .96) / 2) - (size[1] / 2)))
        else:
            self.window.blit(text, (self.position[0] + ((self.dimensions[0]) / 2) - (size[0] / 2), self.position[1] + ((self.dimensions[1]) / 2) - (size[1] / 2)))


    def update(self):
        if self.is_clickable:
            hovering = self.mouse_collision()
            self.set_color(Colors.RED)
            if hovering:
                self.set_color(Colors.DARKRED)

            if hovering and pygame.mouse.get_pressed(3)[0] and time.time() - self.cooldown_start > self.cooldown:
                self.cooldown_start = time.time()
                pygame.mixer.Sound("resources\\click.wav").play()
                if self.function is not None:
                    self.function()
            if time.time() - self.cooldown_start < self.cooldown:
                self.set_color(Colors.FORESTGREEN)

    def mouse_collision(self):
        mpos = pygame.mouse.get_pos()

        x_collide = self.position[0] + self.dimensions[0] > mpos[0] > self.position[0]
        y_collide = self.position[1] + self.dimensions[1] > mpos[1] > self.position[1]
        if y_collide and x_collide:
            return True
        else:
            return False

    def set_color(self, color):
        self.color = color

    def set_label_color(self, color):
        self.label_color = color
