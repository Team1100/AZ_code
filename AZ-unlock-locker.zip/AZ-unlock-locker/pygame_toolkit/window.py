import pygame

class Window:
    pygame.init()
    def __init__(self, WINDOW_DIMS, WINDOW_NAME, color=(255, 255, 255)):
        self.window = pygame.display.set_mode(WINDOW_DIMS, pygame.RESIZABLE)
        pygame.display.set_caption(WINDOW_NAME)
        self.elements = []
        self.color = color

    def update(self):
        pygame.display.flip()
        self.window.fill(self.color)
        for element in self.elements:
            if element.is_renderable:
                element.render()
            element.update()


    def add_element(self, new_element):
        for element in self.elements:
            if element.name == new_element.name:
                raise Exception("Cannot have elements with duplicate names.")
        self.elements += [new_element]

    def get_element_index(self, name):
        for element in self.elements:
            if element.name == name:
                return self.elements.index(element)

